const config = {
    
    connectionLimit : 100,
    host: 'bancodealimentosdb.c9k4qkxktz6x.us-east-1.rds.amazonaws.com', //db-meta.coikvaadq6ut.us-east-1.rds.amazonaws.com
    user : 'root', //admin
    
    password : 'Cat-060122', //rootroot
    database : 'BancoDeAlimentos', //metaverse
    debug : false

    /* 
    host: 'localhost', //db-meta.coikvaadq6ut.us-east-1.rds.amazonaws.com
    user : 'admin', //admin
    */
};

module.exports = config;