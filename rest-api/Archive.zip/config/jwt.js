module.exports = {
    key : 'coolestKittenOnEarthLikesFurros789$'
}